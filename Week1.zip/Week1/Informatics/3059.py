a = int(input())
x = 1
while(x <= a):
	print(x)
	x = x*2