n = int(input())
s = set()
for x in range(n):
    s.add(str(input()))
print(len(s))