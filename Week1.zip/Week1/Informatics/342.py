a = 0
for x in range(0, 100):
	a = a + int(input())
print(a)