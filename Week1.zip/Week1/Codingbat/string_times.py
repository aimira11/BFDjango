def string_times(str, n):
  result = ""
  i = 0
  while i<n:
    result +=str
    i += 1
  return result