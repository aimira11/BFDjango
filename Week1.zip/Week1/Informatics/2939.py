n = int(input())
k = int(input())

m = int(k//n)
print(k - m*n)