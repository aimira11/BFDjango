num = int(input())
print('The next number for the number '+str(num)+' is '+str(num+1)+'.')
print('The previous number for the number '+str(num)+' is '+str(num-1)+'.')