def first_half(str):
  return str[0:len(str)/2]