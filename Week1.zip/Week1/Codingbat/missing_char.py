def missing_char(str, n):
  return str[0:n] + str[n+1:]