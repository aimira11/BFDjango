def has23(nums):
  if 2 in nums or 3 in nums:
    return True
  else:
    return False
