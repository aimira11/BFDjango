def sorta_sum(a, b):
   total = a+b
   if total > 9 and total < 20:   
     return 20 
   else:   
     return total