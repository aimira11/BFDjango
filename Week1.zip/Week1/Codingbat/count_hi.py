def count_hi(str):
  a = str.split('hi')  
  return len(a) - 1