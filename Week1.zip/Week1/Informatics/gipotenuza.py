import math
a = int(input())
b = int(input())
print(math.sqrt(a*a + b*b))