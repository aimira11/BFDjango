def sum_double(a, b):
  result = a+b
  if (a == b):
     result = 2*result
  return result
