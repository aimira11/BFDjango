a = int(input())
b = 0
for x in range(0, a):
	b = b + int(input())
print(b)