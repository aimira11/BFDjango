a = int(input())
k, j = 0, 0
for x in range(0, a):
	j = int(input())
	if j is 0: k = k + 1
print(k)