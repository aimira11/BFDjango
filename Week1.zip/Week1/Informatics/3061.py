a = int(input())
b = 1
i = 0
while(b < a):
	b = b*2
	i = i + 1
print(i)