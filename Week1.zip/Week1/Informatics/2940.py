import math

v = int(input())
t = int(input())

print(int(v*t) % 109)