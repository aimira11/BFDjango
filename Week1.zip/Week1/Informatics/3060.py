a = int(input())
b = 1
while(b != a and b <= a):
	b = b*2
if b is a:
	print("YES")
else:
	print("NO")