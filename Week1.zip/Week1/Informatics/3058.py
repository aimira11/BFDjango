a = int(input())
for x in range(2, a + 1):
	if a%x is 0: 
		print(x) 
		break