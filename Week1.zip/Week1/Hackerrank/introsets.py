def average(array):
    return sum(array)/len(array)