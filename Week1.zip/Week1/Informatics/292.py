a = int(input())
b = int(input())

if (a > b):
    print(a)
else:
    print(b)