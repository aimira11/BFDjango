def make_ends(nums):
  return [nums[0], nums[-1]]