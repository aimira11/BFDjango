def extra_end(str):
  return 3*(str[-2:])