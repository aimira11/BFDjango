def split_and_join(line):
    return line.replace(" ", "-")