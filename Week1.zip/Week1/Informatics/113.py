import math
a = int(input())
for x in range(1, a + 1):
	if x*x <= a:
		print(x*x)