def print_full_name(a, b):
    print("Hello {} {}! You just delved into python.".format(a, b))